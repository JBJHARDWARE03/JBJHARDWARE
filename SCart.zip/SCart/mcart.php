<?php
session_start();

    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        if(isset($_POST['adcbtn']))
        {
            if(isset($_SESSION['cart']))
            {
                $myItems=array_column($_SESSION['cart'],'itemName');
                
                    if(in_array($_POST['itemName'],$myItems))
                    {
                        echo"                       
                        <script>
                            alert('Item Already Added');
                            window.location.href='index.php';
                        </script>                       
                        ";
                    }
                    else
                    {
                        $countItems=count($_SESSION['cart']);
                        $_SESSION['cart'][$countItems]= array('itemName'=>$_POST['itemName'],'itemPrice'=>$_POST['itemPrice'],'quantity'=>1);
                        echo"                       
                        <script>
                        alert('Item Added');
                        window.location.href ='index.php';
                         </script>
                        ";

                    }                                                   
            }
            else
            {
                $_SESSION['cart'][0]=array('itemName'=>$_POST['itemName'],'itemPrice'=>$_POST['itemPrice'],'quantity'=>1);
                echo"                       
                <script>
                    alert('Item Added');
                    window.location.href ='index.php';
                </script>
                ";
            }
        }
        if(isset($_POST['removeBtn']))
        {
            foreach($_SESSION['cart'] as $key => $value)
            {
                if($value['itemName']==$_POST['itemName'])
                {
                    unset($_SESSION['cart'][$key]);
                    $_SESSION['cart']=array_values($_SESSION['cart']);
                    echo"
                    <script>
                        alert('SUCCESSFULLY REMOVE');
                        window.location.href='cart.php';
                    </script>
                    ";
                }                
            }
        }
    }
?>