<?php include ("header.php"); 

//session_start();
//session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
</head>




<?php
       // print_r($_SESSION['cart']);
?>




<body>
    <div class ="container">
        <div class ="row">
            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php" method ="POST">
                    <div class="card">
                        <img src="prdct/1.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">KEYED ENTRY DOORKNOB</h3>
                                    <p class="card-text">PHP 430.00</p>
                                    <p>Uncrackable key entry door. Good for security purposes</p>
                                         <button name = "adcbtn" type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="KEYED ENTRY DOORKNOB">
                                         <input type ="hidden" name="itemPrice" value="430">
                             
                             
                             </div>
                    </div>
                </form>

            </div>

            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php"method ="POST">
                    <div class="card">
                        <img src="prdct/2.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">EURO STREAM BIDET SHOWER</h3>
                                    <p class="card-text">PHP 500.00</p>
                                    <p>You will have a cleanest ass in the world.</p>
                                         <button name = "adcbtn"  type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="EURO STREAM BIDET SHOWER">
                                         <input type ="hidden" name="itemPrice" value="500">
                             
                             
                             </div>
                    </div>
                </form>

            </div>

            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php"method ="POST">
                    <div class="card">
                        <img src="prdct/3.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">HIGH-TECH PAINT ROLLER</h3>
                                    <p class="card-text">PHP 800.00</p>
                                    <p>Turns newbie into artist.</p>
                                         <button name = "adcbtn"  type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="HIGH-TECH PAINT ROLLER">
                                         <input type ="hidden" name="itemPrice" value="800">
                             
                             
                             </div>
                    </div>
                </form>

            </div>

            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php"method ="POST">
                    <div class="card">
                        <img src="prdct/4.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">DAVIS ALL AROUND PAINT BRUSH</h3>
                                    <p class="card-text">PHP 430.00</p>
                                    <p>Want to be an artist?, this is may be your tool</p>
                                         <button name = "adcbtn"  type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="DAVIS ALL AROUND PAINT BRUSH">
                                         <input type ="hidden" name="itemPrice" value="120">                                          
                             </div>
                    </div>
                </form>

            </div>

            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php"method ="POST"> 
                    <div class="card">
                        <img src="prdct/5.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">TRITON WORLD CLASS METAL PRIMER</h3>
                                    <p class="card-text">PHP 1200.00</p>
                                    <p>Turn scrap metal into new one</p>
                                         <button name = "adcbtn"  type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="TRITON WORLD CLASS METAL PRIMER">
                                         <input type ="hidden" name="itemPrice" value="1200">                                          
                             </div>
                    </div>
                </form>

            </div>

            <div class ="col-lg-3 mt-3">
                <form action ="mcart.php"method ="POST"> 
                    <div class="card">
                        <img src="prdct/51.jpg" class="card-img-top embed-responsive-item">
                            <div class="card-body">
                                <h3 class="card-title">TRITON WORLD CLASS PAINT</h3>
                                    <p class="card-text">PHP 1450.00</p>
                                    <p>Need to be partner by our brush to unleash all of its potential</p>
                                         <button name = "adcbtn"  type="submit" class="btn btn-outline-warning">ADD TO CART</button>
                                         <input type ="hidden" name="itemName" value="TRITON WORLD CLASS PAINT">
                                         <input type ="hidden" name="itemPrice" value="1450">                                          
                             </div>
                    </div>
                </form>

            </div>
            
        </div>

        
    </div>
</body>
</html>