<?php

include ("header.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CART</title>
    </head>
         <body>
            <div class="container mt-3">
            
                <div class="row">
                
                    <div class="col-lg-12 text-center border rounded bg-light">                   
                        <h1>MY CART</h1>
                    </div>

                    <div class="col-lg-12">
                    
                            <table class="table">
                                <thead class="text-center">
                                     <tr>
                                    <th scope="col">Serial Number</th>
                                    <th scope="col">Item Name</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                <?php
                                
                                $totalPrice=0;
                                $quantity=0;
                                if (isset($_SESSION['cart']))
                                {
                                    foreach($_SESSION['cart'] as $key => $value)
                                    {
                                        $srn = $key+1;
                                        
                                        $totalPrice=$totalPrice+$value['itemPrice'];
                                        
                                        echo"
                                        <tr>
                                            <td>$srn</td>
                                            <td>$value[itemName]</td>
                                            <td>$value[itemPrice]</td>
                                            <td> <input class='text-center' type='number' value='$value[quantity]' min='1' max ='10'> </td>
                                            <td>
                                                <form action ='mcart.php' method ='POST'>
                                                    <button name='removeBtn' class='btn btn-sm btn-outline-danger'>REMOVE</button>
                                                    <input type='hidden' name='itemName' value = '$value[itemName]'>
                                                    </form>
                                            </td>
                                        </tr>  
                                        ";
                                    }
                               }
                                
                                ?>
                                <tr>
                                    <td></td>
                                    <td><b>TOTAL AMOUNT:</b></td>
                                    <td><b><?php echo $totalPrice ?></b></td>
                                    <td></td>
                                    <td><BUTTON class ="btn btn-sm btn-warning">MAKE PURCHASE</BUTTON></td>
                                </tr>
                                </tbody>
                            </table>
                    
                    </div>
                
                </div>    
            </div>
        </body>
</html>