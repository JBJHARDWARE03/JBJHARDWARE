<?php

session_start();

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BJB HARDWARE</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link href="css/bootstrap.css" rel="stylesheet" />
        <link href="css/bootstrap-theme.css" rel="stylesheet" />
    
    </head>
        <body>
        <nav>
          
        </nav>
        <nav class="navbar navbar-expand-lg navbar-light bg-secondary bg-gradient">
        <img src="prdct/logo.png">
  
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">  
    </ul>
        <div>
            <a href="index.php" type="button" class="btn btn-dark"><img src="https://img.icons8.com/cute-clipart/32/000000/home.png"/> HOME</a>
        </div>
        <div>
            <a href ="login.php" type="button" class="btn btn-dark mx-3"><img src="https://img.icons8.com/office/32/000000/exit-sign.png"/>LOGOUT</a>
        </div>
        <div>
        <?php 
        $count=0;
            if(isset($_SESSION['cart']))
            {
                $count=count($_SESSION['cart']);
            }
        ?>
        <a href ="cart.php" type="button" class="btn btn-dark"><img src="https://img.icons8.com/color/32/000000/food-cart.png"/>MY CART (<?php echo $count; ?>)</a>
        </div>
        
  </div>
</nav>
    
        </body>
</html>